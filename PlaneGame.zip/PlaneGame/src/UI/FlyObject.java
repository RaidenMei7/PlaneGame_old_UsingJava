package UI;

import java.awt.image.BufferedImage;

public class FlyObject {
	BufferedImage img;
	int x;
	int y;
	int w;
	int h;

}
